# N-Queens Challenge (12 x 12)
# Backtracking Algorithm

N = 12

board = [[0 for _ in range(N)] for _ in range(N)]

def is_safe(board, row, col):
    # Check left side of current row
    for i in range(col):
        if board[row][i] == 1:
            return False

    # Check upper-left diagonal
    i, j = row, col
    while i >= 0 and j >= 0:
        if board[i][j] == 1:
            return False
        i -= 1
        j -= 1

    # Check lower-left diagonal
    i, j = row, col
    while i < N and j >= 0:
        if board[i][j] == 1:
            return False
        i += 1
        j -= 1

    return True

def solve(board, col):
    if col >= N:
        return True

    for row in range(N):
        if is_safe(board, row, col):
            board[row][col] = 1

            if solve(board, col + 1):
                return True

            board[row][col] = 0

    return False

if solve(board, 0):
    print("12-Queens Solution:\n")

    moves = 0
    for i in range(N):
        for j in range(N):
            if board[i][j] == 1:
                print("Q", end=" ")
                moves += 1
            else:
                print(".", end=" ")
        print()

    print("\nQueens Placed:", moves)
    print("Conflicts: 0")
else:
    print("No solution exists.")
